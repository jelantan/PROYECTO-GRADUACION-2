// public/panel.js
(async function () {
  const who = document.getElementById('who');
  const adminBlock = document.getElementById('adminActions');
  const engineerBlock = document.getElementById('engineerActions');

  async function getJSON(url) {
    const r = await fetch(url, { credentials: 'include' });
    const ct = r.headers.get('content-type') || '';
    const data = ct.includes('application/json') ? await r.json().catch(() => ({})) : await r.text().catch(() => '');
    if (!r.ok) throw new Error(typeof data === 'object' && data?.error ? data.error : (data || `HTTP ${r.status}`));
    return data;
  }

  try {
    const me = await getJSON('/api/auth/me'); // { username, role }
    who.textContent = `Conectado como ${me.username} [${me.role}]`;

    // ✅ Mostrar SOLO lo que toque:
    if (me.role === 'ENGINEER') {
      engineerBlock.classList.remove('hidden');
    } else if (me.role === 'ADMIN') {
      adminBlock.classList.remove('hidden');
    }
  } catch (e) {
    location.href = '/login.html';
    return;
  }

  // Botón de nueva documentación (solo se verá si el bloque está visible)
  const btnDoc = document.getElementById('btnDoc');
  btnDoc?.addEventListener('click', () => {
    location.href = '/engineer.html';
  });

  // Logout
  document.getElementById('logoutBtn').addEventListener('click', async () => {
    try { await fetch('/api/auth/logout', { method: 'POST', credentials: 'include' }); }
    finally { location.href = '/login.html'; }
  });
})();


