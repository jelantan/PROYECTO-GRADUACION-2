const form = document.getElementById("formLogin");
const msg  = document.getElementById("msg");

form.addEventListener("submit", async (e) => {
  e.preventDefault();
  msg.textContent = "";
  try {
    const body = Object.fromEntries(new FormData(form).entries());
    const r = await fetch("/api/auth/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
      credentials: "include"
    });
    if (!r.ok) {
      const err = await r.json().catch(()=> ({}));
      msg.textContent = err.error || `Error HTTP ${r.status}`;
      return;
    }
    // alert("Login correcto (cookie creada).");
    window.location.href = "/panel.html";
  } catch (err) {
    console.error(err);
    msg.textContent = "No se pudo conectar con el servidor.";
  }
});





