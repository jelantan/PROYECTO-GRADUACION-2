// public/documento.js
(function(){
  const msg = document.getElementById('msg');
  const fecha = document.getElementById('fecha');
  const ingeniero = document.getElementById('ingeniero');

  const selNodo = document.getElementById('nodoOlt');
  const selBw   = document.getElementById('bandwidth');

  const fld = {
    nombre_equipo: document.getElementById('nombre_equipo'),
    ip_equipo: document.getElementById('ip_equipo'),
    vlan_servicio: document.getElementById('vlan_servicio'),
    ip_endpoint: document.getElementById('ip_endpoint'),
    subnet_mask: document.getElementById('subnet_mask'),
    ip_gateway: document.getElementById('ip_gateway'),
    puerto_pon: document.getElementById('puerto_pon'),
  };

  function showError(txt){ msg.textContent = txt; }
  function clearError(){ msg.textContent = ''; }

  async function getJSON(url, opts={}){
    const r = await fetch(url, { credentials:'include', ...opts });
    let data = null;
    try{
      const ct = r.headers.get('content-type') || '';
      if (ct.includes('application/json')) data = await r.json();
    }catch(_){}
    if (!r.ok) throw new Error(data?.error || `HTTP ${r.status}`);
    return data;
  }

  function fillAuto(data){
    if (!data) return;
    Object.keys(fld).forEach(k => { if (data[k] !== undefined) fld[k].value = data[k] || ''; });
  }

  async function loadConstants(){
    const c = await getJSON('/api/docs/constants');
    fecha.value = c.fecha || '';
    ingeniero.value = c.ingeniero || '';
  }

  async function loadOptions(){
    // Bandwidth
    const bw = await getJSON('/api/docs/opciones/BANDWIDTH');
    selBw.innerHTML = '<option value="">-- Seleccione --</option>' +
      (bw||[]).map(o => `<option value="${o.Valor}">${o.Valor}</option>`).join('');

    // Nodo OLT
    const nodos = await getJSON('/api/docs/opciones/NODO_OLT');
    selNodo.innerHTML = '<option value="">-- Seleccione --</option>' +
      (nodos||[]).map(o => `<option value="${o.Valor}">${o.Valor}</option>`).join('');
  }

  async function tryAuto(){
    clearError();
    const nodo = selNodo.value;
    if (!nodo) { fillAuto({}); return; }
    const bw = selBw.value;
    const q = new URLSearchParams({ nodo_olt: nodo, bandwidth: bw || '' }).toString();
    const data = await getJSON(`/api/docs/auto?${q}`);
    fillAuto(data);
  }

  // Init
  (async ()=>{
    try{
      await loadConstants();
      await loadOptions();
    }catch(e){
      console.error('Init error:', e);
      showError('No se pudo inicializar: ' + e.message);
      return;
    }

    selNodo.addEventListener('change', () => tryAuto().catch(e => showError(e.message)));
    selBw.addEventListener('change', () => tryAuto().catch(e => showError(e.message)));

    // Opcional: autocompletar si ya hay valores
    tryAuto().catch(()=>{});
  })();

  // Enviar para generar DOCX
  const form = document.getElementById('formDoc');
  form.addEventListener('submit', async (ev)=>{
    ev.preventDefault(); clearError();
    try{
      const data = Object.fromEntries(new FormData(form).entries());
      // agrega también los campos autocompletados
      data.fecha = fecha.value;
      data.ingeniero = ingeniero.value;
      data.nodo_olt = selNodo.value;
      data.bandwidth = selBw.value;
      Object.keys(fld).forEach(k => data[k] = fld[k].value);

      const r = await fetch('/api/docs/generar', {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type':'application/json' },
        body: JSON.stringify(data)
      });
      if (!r.ok) throw new Error((await r.json()).error || `HTTP ${r.status}`);

      const blob = await r.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url; a.download = `instalacion_${Date.now()}.docx`;
      document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url);
    }catch(e){
      console.error('generar', e);
      showError('No se pudo generar el documento: ' + e.message);
    }
  });
})();
