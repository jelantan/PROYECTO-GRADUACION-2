// public/engineer.js
(async function () {
  const $ = (id) => document.getElementById(id);
  const msg = $('msg');
  const msg2 = $('msg2');

  function showMsg(t) { msg.textContent = t || ''; }
  function showMsg2(t) { msg2.textContent = t || ''; }

  async function getJSON(url) {
    const r = await fetch(url, { credentials: 'include' });
    if (!r.ok) throw new Error((await r.text()) || `HTTP ${r.status}`);
    const ct = r.headers.get('content-type') || '';
    return ct.includes('application/json') ? r.json() : null;
  }

  async function postFile(url, data) {
    const r = await fetch(url, {
      method: 'POST',
      credentials: 'include',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    if (!r.ok) {
      const ct = r.headers.get('content-type') || '';
      let detail = '';
      if (ct.includes('application/json')) {
        const j = await r.json().catch(() => ({}));
        detail = j.detail ? JSON.stringify(j.detail) : j.error || '';
      } else {
        detail = await r.text().catch(() => '');
      }
      throw new Error(`No se pudo generar: ${detail}`);
    }
    return r.blob();
  }

  // 1) Encabezado auto: fecha + ingeniero
  try {
    const c = await getJSON('/api/docs/constants'); // {fecha, ingeniero, empresa_nombre}
    $('x_fecha').value = c.fecha || '';
    $('x_ingeniero').value = c.ingeniero || '';
    $('EmpresaNombre').value = c.empresa_nombre || '';
  } catch (e) {
    console.error(e);
    showMsg('No se pudo cargar fecha/ingeniero');
  }

  // 2) Cargar opciones
  async function cargarNodos() {
    try {
      const lista = await getJSON('/api/docs/opciones/nodosolt'); // [{id,nombre}]
      const sel = $('NodoOlt');
      sel.innerHTML = '<option value="">-- Selecciona --</option>';
      lista.forEach(it => {
        const opt = document.createElement('option');
        opt.value = it.id;
        opt.textContent = it.nombre;
        sel.appendChild(opt);
      });
    } catch (e) {
      console.error(e);
      showMsg('No se pudieron cargar nodos OLT');
    }
  }

  async function cargarBandwidth() {
    try {
      const lista = await getJSON('/api/docs/opciones/bandwidth'); // ["50 Mbps", "100 Mbps", ...]
      const sel = $('Bandwidth');
      sel.innerHTML = '<option value="">-- Selecciona --</option>';
      lista.forEach(txt => {
        const opt = document.createElement('option');
        opt.value = txt;
        opt.textContent = txt;
        sel.appendChild(opt);
      });
    } catch (e) {
      console.error(e);
      showMsg('No se pudieron cargar opciones de bandwidth');
    }
  }

  await Promise.all([cargarNodos(), cargarBandwidth()]);

  // 3) Autocompletar al elegir un Nodo OLT (NODO + IMS)
  $('NodoOlt').addEventListener('change', async (ev) => {
    const val = ev.target.value;
    if (!val) return;
    try {
      const a = await getJSON(`/api/docs/auto?nodoOltId=${encodeURIComponent(val)}`);
      // ----- NODO -----
      $('NombreEquipo').value = a.nombre_equipo || '';
      $('IpEquipo').value     = a.ip_equipo || '';
      $('VlanServicio').value = a.vlan_servicio || '';
      $('SubnetMask').value   = a.subnet_mask || '';
      $('IpGateway').value    = a.ip_gateway || '';
      $('PuertoPon').value    = a.puerto_pon || '';
      $('IpEndpoint').value   = a.ip_endpoint || ''; // si no existe en tu vista, quedará vacío

      // ----- IMS (nuevo) -----
      $('ImsVlanServicio').value = a.ims_vlan_servicio || '';
      $('ImsSubnetMask').value   = a.ims_subnet_mask || '';
      $('ImsGateway').value      = a.ip_gateway_ims || '';
      // Nota: IpIms y NoTelefonos siguen siendo manuales
    } catch (e) {
      console.error(e);
      showMsg('No se pudo autocompletar desde el nodo OLT');
    }
  });

  // 4) Guardar (placeholder)
  $('btnGuardar')?.addEventListener('click', async () => {
    alert('Aquí podrías guardar en DB si lo necesitas. (No implementado en este snippet)');
  });

  // 5) Generar Documento DOCX
  let btnGenerar = document.getElementById('btnGenerar');
  if (!btnGenerar) {
    btnGenerar = document.createElement('button');
    btnGenerar.id = 'btnGenerar';
    btnGenerar.className = 'primary';
    btnGenerar.type = 'button';
    btnGenerar.textContent = 'Generar documento';
    $('btnGuardar').insertAdjacentElement('afterend', btnGenerar);
  }

  btnGenerar.addEventListener('click', async () => {
    showMsg2('');
    try {
      const payload = {
        // Encabezado
        fecha: $('x_fecha').value,
        ingeniero: $('x_ingeniero').value,
        empresa_nombre: $('EmpresaNombre').value,
        no_instalacion: $('NoInstalacion').value,

        // NODO
        nodo_olt: $('NodoOlt').selectedOptions[0]?.textContent || '',
        nombre_equipo: $('NombreEquipo').value,
        ip_equipo: $('IpEquipo').value,
        vlan_servicio: $('VlanServicio').value,
        ip_endpoint: $('IpEndpoint').value,
        subnet_mask: $('SubnetMask').value,
        ip_gateway: $('IpGateway').value,
        puerto_pon: $('PuertoPon').value,
        bandwidth: $('Bandwidth').value,

        // ONT
        ont_serial: $('OntSerial').value,
        ont_id: $('IdOnt').value,
        etiqueta_ont: $('EtiquetaOnt').value,
        splitter_conexion: $('SplitterConexion').value,
        hilo_splitter: $('HiloSplitter').value,

        // IMS
        ims_vlan_servicio: $('ImsVlanServicio').value,
        ip_ims: $('IpIms').value,
        ims_subnet_mask: $('ImsSubnetMask').value,
        ip_gateway_ims: $('ImsGateway').value,
        no_telefonos: $('NoTelefonos').value,

        // GESTIÓN ONT
        gestion_ip_ont: $('GestionIpOnt').value,
        gestion_gateway: $('GestionGateway').value,

        // PÚBLICA
        ip_publica: $('PublicaIpPublica').value,
        ip_privada: $('PublicaIpPrivada').value,
        privada_gateway: $('PublicaGateway').value,

        // Observaciones
        observaciones: document.getElementById('Observaciones')?.value || ''
      };

      const blob = await postFile('/api/docs/generar', payload);
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `Instalacion_${payload.no_instalacion || 'sin_numero'}.docx`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
      showMsg2('Documento generado ✅');
    } catch (e) {
      console.error(e);
      showMsg2(e.message || 'Error al generar');
    }
  });
})();

