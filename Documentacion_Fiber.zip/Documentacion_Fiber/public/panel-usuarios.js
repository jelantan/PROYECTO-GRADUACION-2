// public/panel-usuarios.js
(async function(){
  const tbody = document.getElementById('tbodyUsers');
  const msg = document.getElementById('msg');
  const btnRefrescar = document.getElementById('btnRefrescar');
  const btnCrear = document.getElementById('btnCrear');
  const $ = (id) => document.getElementById(id);

  function showErr(t){ msg.textContent = t || ''; }
  function esc(s){ return String(s ?? '').replace(/[&<>"']/g, m=>({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[m])); }

  async function getJSON(url, opts={}){
    const r = await fetch(url, { credentials:'include', ...opts });
    let data = null;
    try {
      if ((r.headers.get('content-type')||'').includes('application/json')) data = await r.json();
    } catch(_){}
    if (!r.ok){
      if (r.status === 401) { location.href='/login.html'; return; }
      throw new Error(data?.error || `HTTP ${r.status}`);
    }
    return data;
  }

  async function cargar(){
    showErr('');
    tbody.innerHTML = '<tr><td colspan="6">Cargando...</td></tr>';
    try{
      const users = await getJSON('/api/admin/users');
      if (!users?.length){
        tbody.innerHTML = '<tr><td colspan="6">Sin usuarios</td></tr>';
        return;
      }
      tbody.innerHTML = users.map(u => `
        <tr>
          <td>${esc(u.Id)}</td>
          <td>${esc(u.Username)}</td>
          <td>${esc(u.Nombre || '')}</td>
          <td>${esc(u.Email || '')}</td>
          <td>
            <select data-id="${u.Id}" class="sel-role">
              <option value="ENGINEER" ${u.Role==='ENGINEER'?'selected':''}>ENGINEER</option>
              <option value="ADMIN" ${u.Role==='ADMIN'?'selected':''}>ADMIN</option>
            </select>
          </td>
          <td style="display:flex;gap:8px;">
            <button data-id="${u.Id}" class="btn-reset muted" type="button">Reset pass</button>
            <button data-id="${u.Id}" class="btn-del danger" type="button">Eliminar</button>
          </td>
        </tr>
      `).join('');
    }catch(e){
      console.error(e);
      showErr('Error al listar usuarios');
      tbody.innerHTML = '<tr><td colspan="6">Error al cargar</td></tr>';
    }
  }

  // Crear
  btnCrear?.addEventListener('click', async ()=>{
    showErr('');
    const username = $('c_username').value.trim();
    const nombre   = $('c_nombre').value.trim();
    const email    = $('c_email').value.trim();
    const password = $('c_password').value;
    const role     = $('c_role').value;
    if (!username || !password){ showErr('Usuario y contraseña son obligatorios'); return; }
    try{
      await getJSON('/api/admin/users', {
        method:'POST',
        headers:{ 'Content-Type':'application/json' },
        body: JSON.stringify({ username, nombre, email, password, role })
      });
      $('c_username').value = '';
      $('c_nombre').value = '';
      $('c_email').value = '';
      $('c_password').value = '';
      $('c_role').value = 'ENGINEER';
      await cargar();
    }catch(e){
      console.error(e);
      showErr('No se pudo crear');
    }
  });

  // Cambiar rol / reset / eliminar (delegación)
  tbody.addEventListener('change', async (ev)=>{
    const sel = ev.target.closest('.sel-role'); if (!sel) return;
    try{
      await getJSON(`/api/admin/users/${sel.getAttribute('data-id')}/role`, {
        method:'PUT',
        headers:{ 'Content-Type':'application/json' },
        body: JSON.stringify({ role: sel.value })
      });
    }catch(e){ console.error(e); showErr('No se pudo actualizar rol'); }
  });

  tbody.addEventListener('click', async (ev)=>{
    const bDel = ev.target.closest('.btn-del');
    const bReset = ev.target.closest('.btn-reset');

    if (bDel){
      const id = bDel.getAttribute('data-id');
      if (!confirm('¿Eliminar usuario?')) return;
      try{
        await getJSON(`/api/admin/users/${id}`, { method:'DELETE' });
        await cargar();
      }catch(e){ console.error(e); showErr('No se pudo eliminar'); }
    }

    if (bReset){
      const id = bReset.getAttribute('data-id');
      const pwd = prompt('Nueva contraseña temporal:','123456');
      if (!pwd) return;
      try{
        await getJSON(`/api/admin/users/${id}/password`, {
          method:'PUT',
          headers:{ 'Content-Type':'application/json' },
          body: JSON.stringify({ password: pwd })
        });
        alert('Contraseña reseteada');
      }catch(e){ console.error(e); showErr('No se pudo resetear'); }
    }
  });

  btnRefrescar.addEventListener('click', cargar);
  cargar();
})();

