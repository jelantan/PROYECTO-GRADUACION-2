// server.js
const path = require('path');
const express = require('express');
const cookieParser = require('cookie-parser');
const jwt = require('jsonwebtoken');
require('dotenv').config();

const app = express();

// --- middlewares base ---
app.use(cookieParser());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// --- inyecta req.user desde la cookie JWT ---
app.use((req, _res, next) => {
  try {
    const token = req.cookies?.token;
    if (token) {
      const p = jwt.verify(token, process.env.JWT_SECRET);
      req.user = { id: p.id, username: p.username, role: p.role };
    }
  } catch (_e) {
    // token inválido => se ignora y sigue como no autenticado
  }
  next();
});

// --- estáticos ---
app.use(express.static(path.join(__dirname, 'public')));

// --- rutas API ---
app.use('/api/auth', require('./src/routes/auth.routes'));   // ya lo tienes
app.use('/api/docs', require('./src/routes/docs.routes'));   // ya lo tienes
app.use('/api/admin', require('./src/routes/admin.routes')); // NUEVO ADMIN

// --- health check útil para depurar ---
app.get('/api/health/db', async (req, res) => {
  try {
    const odbc = require('odbc');
    const c = await odbc.connect(process.env.SQL_CONN);
    const rs = await c.query('select db_name() as db, suser_sname() as who, @@SERVICENAME as svc');
    await c.close();
    res.json(rs[0]);
  } catch (e) {
    res.status(500).json({ error: 'db', detail: String(e.message || e) });
  }
});

// fallback API
app.use('/api', (_req, res) => res.status(404).json({ error: 'No encontrado' }));

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`API lista: http://localhost:${port}`));
