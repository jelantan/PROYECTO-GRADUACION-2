// src/routes/docs.routes.js
const express = require('express');
const {
  constantes,
  listarOpciones,
  autocompletar,
  generarDoc,
} = require('../controllers/docs.controller');

const router = express.Router();

// Middlewares de auth
function requireAuth(req, res, next) {
  if (!req.user) return res.status(401).json({ error: 'No autenticado' });
  next();
}
function requireEngineer(req, res, next) {
  if (!req.user || (req.user.role !== 'ENGINEER' && req.user.role !== 'ADMIN')) {
    return res.status(403).json({ error: 'Sin permisos' });
  }
  next();
}

// Rutas
router.get('/constants', requireAuth, constantes);
router.get('/opciones/:grupo', requireEngineer, listarOpciones);
router.get('/auto', requireEngineer, autocompletar);
router.post('/generar', requireEngineer, generarDoc);

module.exports = router;

