// src/routes/health.routes.js
const { Router } = require('express');
const { query } = require('../db');

const router = Router();

router.get('/health/db', async (_req, res) => {
  try {
    const r = await query('SELECT 1 AS ok');
    res.json({ ok: true, db: r.recordset[0].ok });
  } catch (e) {
    console.error('[HEALTH] DB error:', e);
    res.status(500).json({ ok: false, error: String(e.message || e) });
  }
});

module.exports = router;
