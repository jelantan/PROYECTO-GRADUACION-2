// src/routes/admin.routes.js
const express = require('express');
const bcrypt = require('bcryptjs');
const odbc = require('odbc');

const router = express.Router();

// Reutilizable
async function execQuery(sql, params) {
  const conn = await odbc.connect(process.env.SQL_CONN);
  try {
    // odbc.query acepta (sql) o (sql, params). Si no hay params, no los pases.
    const rs = Array.isArray(params) ? await conn.query(sql, params) : await conn.query(sql);
    return rs;
  } finally {
    try { await conn.close(); } catch {}
  }
}

// Solo ADMIN
function requireAdmin(req, res, next) {
  if (!req.user) return res.status(401).json({ error: 'No autenticado' });
  if (req.user.role !== 'ADMIN') return res.status(403).json({ error: 'Solo ADMIN' });
  next();
}

// ===== CRUD USUARIOS =====

// Listar
router.get('/users', requireAdmin, async (_req, res) => {
  try {
    const rs = await execQuery(`
      SELECT Id, Username, Nombre, Email, Role, CreatedAt
      FROM dbo.Usuario
      ORDER BY Id ASC
    `);
    res.json(rs);
  } catch (e) {
    console.error('[ADMIN] GET /users ERROR:', e);
    res.status(500).json({ error: 'Error al listar usuarios' });
  }
});

// Crear
router.post('/users', requireAdmin, async (req, res) => {
  try {
    const { username, nombre, email, password, role } = req.body || {};
    if (!username || !password || !role) {
      return res.status(400).json({ error: 'username, password y role son requeridos' });
    }

    const dup = await execQuery(`SELECT 1 AS x FROM dbo.Usuario WHERE Username = ?`, [username]);
    if (dup.length) return res.status(409).json({ error: 'El usuario ya existe' });

    const hash = await bcrypt.hash(password, 10);
    await execQuery(
      `INSERT INTO dbo.Usuario (Username, Nombre, Email, PasswordHash, Role, CreatedAt)
       VALUES (?, ?, ?, ?, ?, GETDATE())`,
      [username, nombre || null, email || null, hash, role]
    );

    const rs = await execQuery(
      `SELECT TOP 1 Id, Username, Nombre, Email, Role, CreatedAt
         FROM dbo.Usuario WHERE Username = ? ORDER BY Id DESC`,
      [username]
    );
    res.status(201).json(rs[0] || { ok: true });
  } catch (e) {
    console.error('[ADMIN] POST /users ERROR:', e);
    res.status(500).json({ error: 'Error al crear usuario' });
  }
});

// Cambiar rol
router.put('/users/:id/role', requireAdmin, async (req, res) => {
  try {
    const id = Number(req.params.id);
    const { role } = req.body || {};
    if (!id || !role) return res.status(400).json({ error: 'id y role requeridos' });

    await execQuery(`UPDATE dbo.Usuario SET Role = ? WHERE Id = ?`, [role, id]);
    res.json({ ok: true });
  } catch (e) {
    console.error('[ADMIN] PUT /users/:id/role ERROR:', e);
    res.status(500).json({ error: 'Error al actualizar rol' });
  }
});

// Resetear contraseña
router.put('/users/:id/password', requireAdmin, async (req, res) => {
  try {
    const id = Number(req.params.id);
    const { password } = req.body || {};
    if (!id || !password) return res.status(400).json({ error: 'id y password requeridos' });

    const hash = await bcrypt.hash(password, 10);
    await execQuery(`UPDATE dbo.Usuario SET PasswordHash = ? WHERE Id = ?`, [hash, id]);
    res.json({ ok: true });
  } catch (e) {
    console.error('[ADMIN] PUT /users/:id/password ERROR:', e);
    res.status(500).json({ error: 'Error al resetear contraseña' });
  }
});

// Eliminar
router.delete('/users/:id', requireAdmin, async (req, res) => {
  try {
    const id = Number(req.params.id);
    if (!id) return res.status(400).json({ error: 'id requerido' });

    await execQuery(`DELETE FROM dbo.Usuario WHERE Id = ?`, [id]);
    res.status(204).end();
  } catch (e) {
    console.error('[ADMIN] DELETE /users/:id ERROR:', e);
    res.status(500).json({ error: 'Error al eliminar usuario' });
  }
});

module.exports = router;



