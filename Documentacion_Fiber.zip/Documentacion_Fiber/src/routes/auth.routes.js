const r = require('express').Router();
const ctrl = require('../controllers/auth.controller');

r.post('/login',  ctrl.login);
r.post('/logout', ctrl.logout);
r.get('/me',      ctrl.me);

module.exports = r;
