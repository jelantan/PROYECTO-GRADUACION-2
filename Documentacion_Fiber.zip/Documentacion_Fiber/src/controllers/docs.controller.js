// src/controllers/docs.controller.js
const fs = require('fs');
const path = require('path');
const PizZip = require('pizzip');
const Docxtemplater = require('docxtemplater');
const odbc = require('odbc');

// ---------- util común ----------
function sendJSON(res, status, payload) {
  if (typeof res.status === 'function' && typeof res.json === 'function') {
    return res.status(status).json(payload);
  }
  res.statusCode = status;
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  res.end(JSON.stringify(payload));
}

async function execQuery(sql, params = []) {
  const conn = await odbc.connect(process.env.SQL_CONN);
  try {
    return await conn.query(sql, params);
  } finally {
    await conn.close();
  }
}

// === (A) constantes: fecha + ingeniero ===
exports.constantes = (req, res) => {
  if (!req.user) return sendJSON(res, 401, { error: 'No autenticado' });

  const hoy = new Date();
  const dd = String(hoy.getDate()).padStart(2, '0');
  const mm = String(hoy.getMonth() + 1).padStart(2, '0');
  const yyyy = hoy.getFullYear();

  sendJSON(res, 200, {
    fecha: `${dd}/${mm}/${yyyy}`,
    ingeniero: req.user.username || '',
    empresa_nombre: process.env.APP_EMPRESA || 'Fiber Documentación',
  });
};

// === (B) listar opciones (usa las VISTAS) ===
// GET /api/docs/opciones/:grupo
// - NODO OLT  -> dbo.v_NodosOlt (Id, Nombre, Activo=1)              => [{id, nombre}]
// - BANDWIDTH -> dbo.v_Opciones (Grupo='BANDWIDTH', Texto, Activo=1) => ["50 Mbps", ...]
exports.listarOpciones = async (req, res) => {
  if (!req.user) return sendJSON(res, 401, { error: 'No autenticado' });

  try {
    const grupo = (req.params.grupo || '').trim().toUpperCase();
    if (!grupo) return sendJSON(res, 400, { error: 'grupo requerido' });

    if (grupo === 'NODOSOLT' || grupo === 'NODO_OLT') {
      const rs = await execQuery(
        `SELECT Id, Nombre
           FROM dbo.v_NodosOlt
          WHERE Activo = 1
       ORDER BY Nombre ASC`
      );
      const data = rs.map(r => ({ id: r.Id, nombre: r.Nombre }));
      return sendJSON(res, 200, data);
    }

    if (grupo === 'BANDWIDTH') {
      const rs = await execQuery(
        `SELECT Texto
           FROM dbo.v_Opciones
          WHERE Grupo = ? AND Activo = 1
       ORDER BY Texto ASC`,
        ['BANDWIDTH']
      );
      const data = rs.map(r => r.Texto);
      return sendJSON(res, 200, data);
    }

    return sendJSON(res, 400, { error: 'grupo no soportado' });
  } catch (e) {
    console.error('[opciones]', e);
    return sendJSON(res, 500, { error: 'No se pudieron cargar opciones' });
  }
};

// === (C) autocompletar al elegir Nodo OLT (robusto a nombres distintos) ===
// GET /api/docs/auto?nodoOltId=#
exports.autocompletar = async (req, res) => {
  if (!req.user) return sendJSON(res, 401, { error: 'No autenticado' });

  try {
    const nodoId = parseInt(req.query.nodoOltId, 10);
    if (!nodoId) return sendJSON(res, 400, { error: 'nodoOltId requerido' });

    // Seleccionamos * para evitar errores de compilación si cambian los nombres.
    const rs = await execQuery(
      `SELECT *
         FROM dbo.v_NodosOlt
        WHERE Id = ? AND Activo = 1`,
      [nodoId]
    );

    if (!rs || rs.length === 0) return sendJSON(res, 404, { error: 'Nodo no encontrado' });

    const r = rs[0];

    // Helper: devuelve el primer campo existente entre varios posibles
    const pick = (...keys) => {
      for (const k of keys) {
        if (r.hasOwnProperty(k) && r[k] != null) return r[k];
      }
      return '';
    };

    const payload = {
      // nombre del equipo
      nombre_equipo:  pick('NombreEquipo', 'Nombre'),

      // IP y capa 3
      ip_equipo:      pick('IpEquipo', 'IPEquipo', 'Ip_Equipo'),
      vlan_servicio:  pick('VlanServicio', 'VLANServicio', 'Vlan_Servicio'),
      ip_endpoint:    pick('IpEndpoint', 'IPEndpoint', 'Ip_EndPoint', 'IP_EndPoint', 'EndpointIp', 'EndPointIp'),
      subnet_mask:    pick('SubnetMask', 'Subnet_Mask', 'Mascara', 'MascaraSubred', 'Mascara_Subred'),
      ip_gateway:     pick('IpGateway', 'IPGateway', 'Gateway', 'PuertaEnlace', 'DefaultGateway'),
      puerto_pon:     pick('PuertoPon', 'PuertoPON', 'Puerto_Pon', 'PonPort', 'PONPort'),

      // IMS (si existen en la vista, si no, quedan vacíos)
      ims_vlan_servicio: pick('ImsVlanServicio', 'IMS_VlanServicio', 'IMS_VLAN', 'VlanIMS'),
      ims_subnet_mask:   pick('ImsSubnetMask', 'IMS_SubnetMask', 'MascaraIMS', 'IMS_Mascara'),
      ip_gateway_ims:    pick('IpGatewayIms', 'IPGatewayIMS', 'GatewayIMS', 'IMS_Gateway'),
    };

    return sendJSON(res, 200, payload);
  } catch (e) {
    console.error('[auto]', e);
    return sendJSON(res, 500, { error: 'No se pudo autocompletar' });
  }
};

// === (D) GENERAR DOCUMENTO (sin cambios) ===
// POST /api/docs/generar
exports.generarDoc = async (req, res) => {
  try {
    if (!req.user) return sendJSON(res, 401, { error: 'No autenticado' });

    const data = {
      // Encabezado
      fecha: req.body.fecha || '',
      ingeniero: req.user.username || '',
      empresa_nombre: req.body.empresa_nombre || process.env.APP_EMPRESA || 'Fiber Documentación',
      no_instalacion: req.body.no_instalacion || '',

      // NODO
      nodo_olt: req.body.nodo_olt || '',
      nombre_equipo: req.body.nombre_equipo || '',
      ip_equipo: req.body.ip_equipo || '',
      vlan_servicio: req.body.vlan_servicio || '',
      ip_endpoint: req.body.ip_endpoint || '',
      subnet_mask: req.body.subnet_mask || '',
      ip_gateway: req.body.ip_gateway || '',
      puerto_pon: req.body.puerto_pon || '',
      bandwidth: req.body.bandwidth || '',

      // ONT
      ont_serial: req.body.ont_serial || '',
      ont_id: req.body.ont_id || '',
      etiqueta_ont: req.body.etiqueta_ont || '',
      splitter_conexion: req.body.splitter_conexion || '',
      hilo_splitter: req.body.hilo_splitter || '',

      // IMS
      ims_vlan_servicio: req.body.ims_vlan_servicio || '',
      ip_ims: req.body.ip_ims || '',
      ims_subnet_mask: req.body.ims_subnet_mask || '',
      ip_gateway_ims: req.body.ip_gateway_ims || '',
      no_telefonos: req.body.no_telefonos || '',

      // GESTIÓN ONT
      gestion_ip_ont: req.body.gestion_ip_ont || '',
      gestion_gateway: req.body.gestion_gateway || '',

      // PÚBLICA
      ip_publica: req.body.ip_publica || '',
      ip_privada: req.body.ip_privada || '',
      privada_gateway: req.body.privada_gateway || '',

      // Observaciones
      observaciones: req.body.observaciones || ''
    };

    const tplPath = path.join(__dirname, '../../templates/plantilla_instalacion.docx');
    const content = fs.readFileSync(tplPath, 'binary');
    const zip = new PizZip(content);

    const doc = new Docxtemplater(zip, {
      paragraphLoop: true,
      linebreaks: true,
      delimiters: { start: '{{', end: '}}' },
    });

    doc.setData(data);
    doc.render();

    const buf = doc.getZip().generate({ type: 'nodebuffer' });
    const filename = `Instalacion_${data.no_instalacion || 'sin_numero'}.docx`;
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    return res.end(buf);
  } catch (e) {
    console.error('[DOCS] Error al generar DOCX:', e);
    return sendJSON(res, 500, {
      error: 'No se pudo generar el documento',
      detail: (e && e.properties && e.properties.errors) ? e.properties.errors : String(e.message || e)
    });
  }
};


