const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const { query } = require('../db');

function setSession(res, user) {
  const token = jwt.sign(
    { sub: user.Id, username: user.Username, role: user.Role },
    process.env.JWT_SECRET,
    { expiresIn: '8h' }
  );
  res.cookie('token', token, {
    httpOnly: true,
    sameSite: 'lax',
    secure: false,   // en producción con HTTPS => true
    maxAge: 8 * 60 * 60 * 1000
  });
}

async function login(req, res) {
  try {
    const { username, password } = req.body;
    if (!username || !password)
      return res.status(400).json({ error: 'Faltan datos' });

    const sqlText = `
      SELECT TOP 1 Id, Username, Nombre, Email, PasswordHash, Role
      FROM dbo.Usuario
      WHERE Username = @Username
    `;
    const r = await query(sqlText, { Username: username });
    const user = r.recordset?.[0];
    if (!user) return res.status(401).json({ error: 'Credenciales inválidas' });

    const ok = await bcrypt.compare(password, user.PasswordHash);
    if (!ok) return res.status(401).json({ error: 'Credenciales inválidas' });

    setSession(res, user);
    res.json({ id: user.Id, username: user.Username, role: user.Role, nombre: user.Nombre });
  } catch (err) {
    console.error('[AUTH] Error en login:', err);
    res.status(500).json({ error: 'Error interno' });
  }
}

async function logout(_req, res) {
  res.clearCookie('token');
  res.json({ ok: true });
}

function me(req, res) {
  const token = req.cookies?.token;
  if (!token) return res.json(null);
  try {
    const u = jwt.verify(token, process.env.JWT_SECRET);
    return res.json({ id: u.sub, username: u.username, role: u.role });
  } catch {
    return res.json(null);
  }
}

module.exports = { login, logout, me };





