const bcrypt = require('bcryptjs');
const { query } = require('../db');

/** POST /api/admin/users  (crear) */
async function createUser(req, res) {
  const { username, nombre, email, password, role = 'ENGINEER' } = req.body;
  if (!username || !nombre || !password)
    return res.status(400).json({ error: 'username, nombre y password son obligatorios' });

  const roleClean = role === 'ADMIN' ? 'ADMIN' : 'ENGINEER';

  const exists = await query('SELECT 1 AS x FROM dbo.Usuario WHERE Username=@u', { u: username });
  if (exists.recordset.length) return res.status(409).json({ error: 'El username ya existe' });

  const hash = await bcrypt.hash(password, 12);

  await query(`
    INSERT INTO dbo.Usuario (Username, Nombre, Email, PasswordHash, Role)
    VALUES (@u, @n, @e, @h, @r)
  `, { u: username, n: nombre, e: email ?? null, h: hash, r: roleClean });

  return res.status(201).json({ ok: true, username, role: roleClean, nombre });
}

/** GET /api/admin/users  (listar con búsqueda + paginación) */
async function listUsers(req, res) {
  const page = Math.max(parseInt(req.query.page || '1', 10), 1);
  const pageSize = Math.min(Math.max(parseInt(req.query.pageSize || '10', 10), 1), 100);
  const q = (req.query.q || '').trim();

  let where = '1=1';
  const params = {};
  if (q) {
    where = '(Username LIKE @pat OR Nombre LIKE @pat OR Email LIKE @pat)';
    params.pat = `%${q}%`;
  }

  const totalRow = await query(`SELECT COUNT(*) AS total FROM dbo.Usuario WHERE ${where}`, params);
  const total = totalRow.recordset[0].total;
  const offset = (page - 1) * pageSize;

  const data = await query(`
    SELECT Id, Username, Nombre, Email, Role,
           CONVERT(varchar(19), CreatedAt, 120) AS CreatedAt
    FROM dbo.Usuario
    WHERE ${where}
    ORDER BY Id DESC
    OFFSET @offset ROWS FETCH NEXT @pageSize ROWS ONLY
  `, { ...params, offset, pageSize });

  res.json({
    items: data.recordset,
    total,
    page,
    pageSize,
    totalPages: Math.max(1, Math.ceil(total / pageSize))
  });
}

/** PUT /api/admin/users/:id/role  (editar rol) */
async function updateRole(req, res) {
  const id = parseInt(req.params.id, 10);
  const role = (req.body.role || '').toUpperCase().trim();
  if (!Number.isInteger(id) || id <= 0) return res.status(400).json({ error: 'Id inválido' });
  if (!['ADMIN', 'ENGINEER'].includes(role)) return res.status(400).json({ error: 'Rol inválido' });

  // Evita que un admin se quite a sí mismo el rol ADMIN (para no quedarse sin acceso)
  if (req.user?.sub === id && role !== 'ADMIN') {
    return res.status(400).json({ error: 'No puedes quitarte tu propio rol ADMIN' });
  }

  const exists = await query('SELECT 1 AS x FROM dbo.Usuario WHERE Id=@id', { id });
  if (!exists.recordset.length) return res.status(404).json({ error: 'Usuario no encontrado' });

  await query('UPDATE dbo.Usuario SET Role=@r WHERE Id=@id', { r: role, id });
  res.json({ ok: true, id, role });
}

/** PUT /api/admin/users/:id/password  (resetear contraseña) */
async function resetPassword(req, res) {
  const id = parseInt(req.params.id, 10);
  const password = (req.body.password || '').trim();
  if (!Number.isInteger(id) || id <= 0) return res.status(400).json({ error: 'Id inválido' });
  if (!password || password.length < 8) return res.status(400).json({ error: 'La contraseña debe tener al menos 8 caracteres' });

  const exists = await query('SELECT 1 AS x FROM dbo.Usuario WHERE Id=@id', { id });
  if (!exists.recordset.length) return res.status(404).json({ error: 'Usuario no encontrado' });

  const hash = await bcrypt.hash(password, 12);
  await query('UPDATE dbo.Usuario SET PasswordHash=@h WHERE Id=@id', { h: hash, id });
  res.json({ ok: true, id });
}

/** DELETE /api/admin/users/:id  (eliminar) */
async function deleteUser(req, res) {
  const id = parseInt(req.params.id, 10);
  if (!Number.isInteger(id) || id <= 0) return res.status(400).json({ error: 'Id inválido' });

  // Por seguridad: no permitir que un usuario se borre a sí mismo
  if (req.user?.sub === id) return res.status(400).json({ error: 'No puedes eliminarte a ti mismo' });

  const del = await query('DELETE FROM dbo.Usuario WHERE Id=@id', { id });
  const rows = del.rowsAffected?.[0] || 0;
  if (!rows) return res.status(404).json({ error: 'Usuario no encontrado' });

  res.json({ ok: true, id });
}

module.exports = { createUser, listUsers, updateRole, resetPassword, deleteUser };

