require('dotenv').config();
const sql = require('mssql/msnodesqlv8'); // ODBC

const cfg = { connectionString: process.env.SQL_CONN };

let pool;
async function getPool() {
  if (pool) return pool;
  pool = await new sql.ConnectionPool(cfg).connect();
  console.log('[DB] Conectado vía ODBC');
  return pool;
}

async function query(text, params = {}) {
  const p = await getPool();
  const req = p.request();
  Object.entries(params).forEach(([k, v]) => req.input(k, v));
  return req.query(text);
}

module.exports = { query };




